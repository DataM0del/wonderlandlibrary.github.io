#!/bin/bash
java -noverify -jar Seraphon-Launcher.jar